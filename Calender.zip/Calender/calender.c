#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main()
{
    int year, month, firstDay, daysInMonth, i, j, day;

    // Get year and month from user
    printf("Enter year: ");
    scanf("%d", &year);

    printf("Enter month (1-12): ");
    scanf("%d", &month);

    // Determine the number of days in the given month
    if (month == 2)
    {
        if ((year % 4 == 0 && year % 100 != 0) || year % 400 == 0)
        {
            daysInMonth = 29;
        }
        else
        {
            daysInMonth = 28;
        }
    }
    else if (month == 4 || month == 6 || month == 9 || month == 11)
    {
        daysInMonth = 30;
    }
    else
    {
        daysInMonth = 31;
    }

    // Determine the day of the week on the first day of the month
    day = 1;
    struct tm time = {0};
    time.tm_year = year - 1900;
    time.tm_mon = month - 1;
    time.tm_mday = day;
    mktime(&time);
    firstDay = time.tm_wday;

    // Print the calendar header
    printf("\n   Calendar %d / %d \n", month, year);
    printf(" Su Mo Tu We Th Fr Sa\n");

    // Print the calendar body
    for (i = 0; i < firstDay; i++)
    {
        printf("   ");
    }

    for (j = 1; j <= daysInMonth; j++)
    {
        printf("%3d", j);
        if ((j + firstDay) % 7 == 0)
        {
            printf("\n");
        }
    }

    printf("\n");

    return 0;
}
