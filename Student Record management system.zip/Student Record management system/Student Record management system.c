#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Define a struct for student record
struct student {
    char name[50];
    int roll;
    float marks;
} s;

int main()
{
    int choice, count = 0, i;
    FILE *fp;
    fp = fopen("student_data.txt", "ab+");

    // Check if the file exists
    if (fp == NULL) {
        printf("Error opening file.");
        return 1;
    }

    // Display the menu
    while (1) {
        printf("\nStudent Record Management System\n");
        printf("1. Add student record\n");
        printf("2. Display all student records\n");
        printf("3. Exit\n");

        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            // Add a student record
            case 1:
                printf("\nEnter the name of the student: ");
                scanf("%s", s.name);
                printf("Enter the roll number of the student: ");
                scanf("%d", &s.roll);
                printf("Enter the marks of the student: ");
                scanf("%f", &s.marks);

                fwrite(&s, sizeof(s), 1, fp);
                printf("\nStudent record added successfully.\n");
                count++;
                break;

            // Display all student records
            case 2:
                printf("\nAll student records:\n\n");
                rewind(fp);

                for (i = 0; i < count; i++) {
                    fread(&s, sizeof(s), 1, fp);
                    printf("Name: %s\n", s.name);
                    printf("Roll number: %d\n", s.roll);
                    printf("Marks: %.2f\n\n", s.marks);
                }
                break;

            // Exit the program
            case 3:
                fclose(fp);
                printf("\nGoodbye!\n");
                exit(0);

            default:
                printf("Invalid choice.\n");
        }
    }
    return 0;
}
