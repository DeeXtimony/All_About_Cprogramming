#include <stdio.h>
#include <string.h>

#define MAX_CONTACTS 100

struct contact {
    char name[50];
    char phone_number[20];
};

int main() {
    struct contact phonebook[MAX_CONTACTS];
    int num_contacts = 0;
    int choice;

    while (1) {
        printf("Phonebook\n");
        printf("---------\n");
        printf("1. Add contact\n");
        printf("2. Search contact\n");
        printf("3. Display all contacts\n");
        printf("4. Exit\n");

        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1: // Add contact
                if (num_contacts >= MAX_CONTACTS) {
                    printf("Phonebook is full.\n");
                    break;
                }

                printf("Enter name: ");
                scanf("%s", phonebook[num_contacts].name);

                printf("Enter phone number: ");
                scanf("%s", phonebook[num_contacts].phone_number);

                printf("Contact added.\n");
                num_contacts++;
                break;

            case 2: // Search contact
                if (num_contacts == 0) {
                    printf("Phonebook is empty.\n");
                    break;
                }

                printf("Enter name to search: ");
                char search_name[50];
                scanf("%s", search_name);

                int found = 0;
                for (int i = 0; i < num_contacts; i++) {
                    if (strcmp(phonebook[i].name, search_name) == 0) {
                        printf("Name: %s\nPhone number: %s\n", phonebook[i].name, phonebook[i].phone_number);
                        found = 1;
                        break;
                    }
                }

                if (!found) {
                    printf("Contact not found.\n");
                }
                break;

            case 3: // Display all contacts
                if (num_contacts == 0) {
                    printf("Phonebook is empty.\n");
                    break;
                }

                printf("Contacts:\n");
                for (int i = 0; i < num_contacts; i++) {
                    printf("%d. Name: %s\n   Phone number: %s\n", i + 1, phonebook[i].name, phonebook[i].phone_number);
                }
                break;

            case 4: // Exit
                printf("Goodbye!\n");
                return 0;

            default:
                printf("Invalid choice.\n");
        }

        printf("\n");
    }

    return 0;
}
